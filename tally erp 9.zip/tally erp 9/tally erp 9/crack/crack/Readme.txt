1. Install Tally ERP
2. Replace tally.exe
3. Activate License,you can use any serial and activation key,tally will make a tally_req.lic
   in your tallyerp directory,exit tally program,rename tally_req.lic to tally.lic and run 
   tally erp program again,tally should now be activated and ready to use

   Note: You can use a compatible tally.lic for ERP,you can use the Auditor Edition if you can
         get a compatible tally.lic for erp that is an auditor license file
